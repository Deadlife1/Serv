'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable(
            //если в модели явно указали название таблицы, то тут тоже меняем
            'groups', 
            {
                // поле id добавляется автоматически 
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER
                },
                name: {
                    // тут приводим в соответствие с моделью (длина строки)
                    type: Sequelize.STRING(8)
                },
                // поля createdAt и updatedAt тоже создаются автоматически
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE
                }
            });
    },
    down: (queryInterface, Sequelize) => {
        //если в модели явно указали название таблицы, то тут тоже меняем
        return queryInterface.dropTable('groups');
    }
};