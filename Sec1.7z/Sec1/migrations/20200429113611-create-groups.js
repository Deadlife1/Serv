'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable(
            'groups', 
            { 
                id: {
                    allowNull: false,
                    autoIncrement: true,
                    primaryKey: true,
                    type: Sequelize.INTEGER
                },
                name: {
                    // тут приводим в соответствие с моделью (длина строки)
                    type: Sequelize.STRING(8)
                },
                // поля createdAt и updatedAt тоже создаются автоматически
                "createdAt": new Date(){
                    allowNull: false,
                    type: Sequelize.DATE
                },
                "updatedAt": new() {
                    allowNull: false,
                    type: Sequelize.DATE
                }
				module.exports = (sequelize, DataTypes) => {
    const Firm = sequelize.define('Firm', {
        name: DataTypes.STRING,
        ico: DataTypes.STRING
    }, {
        timestamps: false,
        tableName: 'firm'
    });
    return Firm;
};
            });
    },
    down: (queryInterface, Sequelize) => {
        //если в модели явно указали название таблицы, то тут тоже меняем
        return queryInterface.dropTable('groups');
    }
};