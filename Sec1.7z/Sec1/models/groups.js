'use strict';
module.exports = (sequelize, DataTypes) => {
    const Groups = sequelize.define(
        'Groups', // насколько я понимаю - название класса
        {
            /* поля таблицы, тут можно немного подрихтовать, например, уменьшить длину поля */
            name: DataTypes.STRING(8)
        }, 
        {
            /*по-умолчанию тут пусто, но я сюда пишу название таблицы (обычно оно то же что и название класса). дело в том, что под виндой регистр букв значения не имеет, а вот под линуксом могут быть проблемы - лучше явно указать название таблицы в нижнем регистре*/
            tableName: 'groups'
        });
    Groups.associate = function(models) {
        // associations can be defined here
    };
    return Groups;
};